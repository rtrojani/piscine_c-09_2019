/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rotrojan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/06 16:38:46 by rotrojan          #+#    #+#             */
/*   Updated: 2019/07/07 18:29:43 by rotrojan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	rush(int x, int y);

int		main()
{
	rush(5, 5);
	write(1, "\n", 1);
	rush(2, 5);
	write(1, "\n", 1);
	rush(5, 2);
	write(1, "\n", 1);
	rush(2, 2);
	write(1, "\n", 1);
	rush(0, 5);
	write(1, "\n", 1);
	rush(5, 0);
	write(1, "\n", 1);
	rush(0, 0);
	write(1, "\n", 1);
	rush(-5, 5);
	write(1, "\n", 1);
	rush(5, -5);
	write(1, "\n", 1);
	rush(-5, -5);
	write(1, "\n", 1);
	rush('a', 5);
	write(1, "\n", 1);
	rush(5, 'a');
	write(1, "\n", 1);
	rush('a', 'a');
	write(1, "\n", 1);
	return (0);
}
