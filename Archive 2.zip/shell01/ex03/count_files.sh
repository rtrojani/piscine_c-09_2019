find . -not -path '*/\.*' | wc -l | bc
