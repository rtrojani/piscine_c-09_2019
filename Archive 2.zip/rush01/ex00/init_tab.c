/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_tab.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rotrojan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/13 18:54:08 by rotrojan          #+#    #+#             */
/*   Updated: 2019/07/14 18:09:38 by rotrojan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int		count_params(char *str)
{
	int		i;
	int		nb_params;

	i = 0;
	nb_params = 0;
	while (str[i])
	{
		if (!((str[i] >= 9 && str[i] <= 13) || str[i] == 32))
			nb_params++;
		i++;
	}
	return (nb_params);
}

int		check_error(char *str)
{
	int		i;

	i = 0;
	while (str[i])
	{
		if (!i % 2)
			if (!(str[i] >= '0' && str[i] <= '9'))
				return (0);
		if (i % 2)
			if (!((str[i] >= 9 && str[i] <= 13) || str[i] == 32))
				return (0);
		i++;
	}
	if (!(str[i - 1] >= '0' && str[i - 1] <= '9'))
		return (0);
	
	if (count_params(str) % 4)
		return (0);
	return (1);
}

void	fill_zero(int n, int **grid)
{
	int		i;
	int		j;

	j = 0;
	while (j < n + 2)
	{
		i = 0;
		while (i < n + n)
		{
			grid[j][i] = 0;
			i++;
		}
		j++;
	}
}

void	fill_grid1(char *str, int n, int **grid)
{
	int		i;
	int		k;

	k = 0;
	i = 1;
	while (i <= n)
	{
		grid[0][i] = str[k] - '0';
		i++;
		k += 2;
	}

//	printf("n = %d\n", n);
	i = 1;
	while (i <= n)
	{
		grid[n + 1][i] = str[k] - '0';
		i++;
		k += 2;
	}
}

void	fill_grid2(char *str, int n, int **grid)
{
	int		i;
	int		k;

	k = (2 * (n + 1));
	i = 1;
	while (i < n + 2)
	{
		grid[0][i] = str[k] - '0';
		i++;
		k += 2;
		grid[0][i] = str[k] - '0';
	}
	i = 1;
	while (i < n + 2)
	{
		grid[n + 1][i] = str[k] - '0';
		i++;
		k += 2;
	}
}

int		**init_grid(char *str)
{
	int		n;
	int		**grid;
	int		i;

	if (!check_error(str))
	{
		printf("checkerror\n");
		return (NULL);
	}
	n = count_params(str) / 4;
	if (!(grid = (int**)malloc(sizeof(*grid) * (n + 2))))
	{
		printf("mallocerror\n");
		return (NULL);
	}
	i = 0;
	while (i < n + 2)
	{
		if (!(grid[i] = (int*)malloc(sizeof(*grid) * (n + 2))))
			return (NULL);
		i++;
	}
	fill_grid1(str, n, grid);
	fill_grid2(str, n, grid);
	return (grid);
}
