/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rotrojan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/12 16:07:00 by rotrojan          #+#    #+#             */
/*   Updated: 2019/07/16 19:44:57 by rotrojan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		is_separator(char c, char *charset)
{
	int		i;

	i = 0;
	while (charset[i])
	{
		if (c == charset[i])
			return (1);
		i++;
	}
	return (0);
}

int		count_words(char *str, char *charset)
{
	int		nb_words;
	int		i;

	nb_words = 0;
	i = 0;
	if (!*charset)
		return (1);
	while (str[i])
	{
		while (str[i] && is_separator(str[i], charset))
		{
			if (!str[i])
				return (0);
			i++;
		}
		while (str[i] && !is_separator(str[i], charset))
			i++;
		while (str[i] && is_separator(str[i], charset))
			i++;
		nb_words++;
	}
	return (nb_words);
}

void	fill_tab(char *str, char **words, char *charset)
{
	int		i;
	int		j;
	int		k;

	i = 0;
	j = 0;
	while (str[j] && i < count_words(str, charset))
	{
		k = 0;
		while (str[j] && is_separator(str[j], charset))
			j++;
		while (str[j + k] && !is_separator(str[j + k], charset))
		{
			words[i][k] = str[j + k];
			k++;
		}
		words[i][k] = '\0';
		j += k;
		i++;
	}
	words[count_words(str, charset)] = 0;
}

char	**malloc_tab(char *str, char *charset)
{
	char	**words;
	int		i;
	int		j;
	int		k;

	i = 0;
	j = 0;
	if (!(words = (char**)malloc(sizeof(*words)
		* (count_words(str, charset) + 1))))
		return (NULL);
	while (i < count_words(str, charset))
	{
		k = 0;
		while (str[j] && is_separator(str[j], charset))
			j++;
		while (str[j + k] && !is_separator(str[j + k], charset))
			k++;
		if (!(words[i] = (char*)malloc(sizeof(*words) * (k + 1))))
			return (NULL);
		j += k;
		i++;
	}
	words[i] = 0;
	return (words);
}

char	**ft_split(char *str, char *charset)
{
	char	**words;

	if (!*str)
		return (NULL);
	words = malloc_tab(str, charset);
	fill_tab(str, words, charset);
	return (words);
}
