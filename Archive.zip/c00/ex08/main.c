/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rotrojan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/02 18:10:44 by rotrojan          #+#    #+#             */
/*   Updated: 2019/07/03 12:19:54 by rotrojan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

void	ft_print_combn(int n);

int		main(int argc, char **argv)
{
	(void)argc;
	ft_print_combn(atoi(argv[1]));
	return (0);
}
