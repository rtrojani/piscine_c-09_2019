/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_ten_queens_puzzle.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rotrojan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/09 20:44:24 by rotrojan          #+#    #+#             */
/*   Updated: 2019/07/09 20:54:48 by rotrojan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_ten_queens_puzzle(void);

int		main(void)
{
	printf("Nombre de solutions : %d\n", ft_ten_queens_puzzle());
	return (0);
}
