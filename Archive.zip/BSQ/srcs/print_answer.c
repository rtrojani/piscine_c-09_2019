/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_answer.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rotrojan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/24 20:01:16 by rotrojan          #+#    #+#             */
/*   Updated: 2019/07/24 22:00:50 by rotrojan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int		before_square(int fd, t_matrice data, t_param params)
{
	char	c;
	char	*buff;
	int		y;

	y = 0;
	if (!(buff = (char*)malloc(sizeof(*buff) * (params.len + 1))))
		return (-1);
	while (c != '\n')
		read(fd, &c, 1);
	while (y < data.y - data.max)
	{
		read(fd, buff, params.len);
		write(fd, buff, params.len);
		y++;
	}
	return (0);
}

int		print_square(int fd, t_matrice data, t_param params)
{
	
}

int (char *map_path, t_param params, t_matrice data)
{
	int		fd;

	i = 0;
	fd = open(map_path, OR_ONLY);
	if (fd == -1)
		return (-1);
	before_square(fd, data, params);
	while (
		print_square(fd, data, params);
	while (read(fd, buff, params.len + 1) && (i <  max - y))
	{
		write(fd, buff, params.len + 1);
		i++;
	}
	while ()
	{
		while
		{

		}
	}


	
	
}
