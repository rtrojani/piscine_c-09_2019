/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rotrojan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/07 12:02:27 by rotrojan          #+#    #+#             */
/*   Updated: 2019/07/07 12:23:08 by rotrojan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>
#define BUFF 1024

char	*ft_strstr(char *str, char *to_find);

int		main(int argc, char **argv)
{
	char	str[BUFF];
	char	to_find[BUFF];
	char	ft_str[BUFF];
	char	ft_to_find[BUFF];

	(void)argc;
	strcpy(str, argv[1]);
	strcpy(ft_str, argv[1]);
	strcpy(to_find, argv[2]);
	strcpy(ft_to_find, argv[2]);
	printf("      str = %s\n   to_find =%s\n", str, to_find);
	printf("   strstr = %s\n", strstr(str, to_find));
	printf("   ft_str = %s\nft_to_find =%s\n", str, to_find);
	printf("ft_strstr = %s\n", ft_strstr(str, to_find));
	return (0);
}
