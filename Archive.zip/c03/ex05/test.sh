echo "\ntest avec dest = couco & src = wesh wesh ca va & size = 56\n"
./a.out "couco" "wesh wesh ca va" "56"

echo "\ntest avec dest = coucou les amis & src = wesh wes & size = 20\n"
./a.out "coucou les amis" "wesh wes" "20"

echo "\ntest avec dest = wesh wesh les mias ca va & src = coucou le s & size = 5 \n"
./a.out "wesh wesh les mias ca va" "coucou le s" "5"

echo "\ntest avec dest = couc & src = wesh ddd & size = 5\n"
./a.out "couc" "wesh ddd" "5"

echo "\ntest avec dest = coucou & src = wesh & size = 20\n"
./a.out "coucou" "wesh" "20"

echo "\ntest avec dest = couco & src = wesh wesh & size = 8\n"
./a.out "couco" "wesh wesh" "8"

echo "\ntest avec dest = weshdddfff l& src = alors & size = 6\n"
./a.out "weshdddfff" "alors" "6"

echo "\ntest avec dest = coucou les & src = wesh wesh les  & size = 5\n"
./a.out "coucou les" "wesh wesh les " "5"

echo "\ntest avec dest = coucou & src = weshweshweshwesh & size = 0\n"
./a.out "coucou" "weshweshweshwesh" "0"

echo "\ntest avec dest = coucou les amis & src = test & size = 0\n"
./a.out "coucou les amis" "test" "0"

echo "\ntest avec dest = wesh wesh & src = 0  & size = 20\n"
./a.out  "wesh wesh " "" "20"

echo "\ntest avec dest = "" & src = "" & size = 0 \n"
./a.out "" "" ""

